%___________________________________________________________________%
%  UAV path planning optimization (2D & 3D)                                  %
%  Comparing different meta-heuristic algorithms                    %
%                                                                   %
%  Developed in MATLAB R2017b                                       %
%                                                                   %
%  Author and programmer: Soheila Ghambari                          %
%                                                                   %
%         e-Mail: ghambari.soheila@gmail.com                        %
%                 soheila.ghambari@uha.fr                           %
%___________________________________________________________________%

clc;
clear;
close all;
warning off;


% Envrionment information:
S = [200,0];                    % Start point
T = [700, 300];                 % Target point
model = CreateModel(S, T);      % Create Model

% Problem Definition
Num_waypoints =model.n;                     % Number of way_points
D = Num_waypoints*2+Num_waypoints+1;        % number of Handle Points (Decision Variables [x and y] )
CostFunction=@(x) MyCost(x,model);          % Cost Function
lb (1:Num_waypoints*2) = linspace (S(1), S(2), Num_waypoints*2);        % Lower Bound of Variables
ub (1:Num_waypoints*2) = linspace (T(1), T(2), Num_waypoints*2);        % Upper Bound of Variables
Pop_size = 100;                             % Number of population
Max_NFE = 2500;                             % Maximum number of function evaluation
Max_Run = 1;                                % Maximum number of Runs
GlobalBest_Cost = inf;                      % GlobalBest cost 
GlobalBest_param = zeros(1, D);              % GlobalBest variables
pos = zeros (1, D);

for r = 1: Max_Run
    
    fprintf('Run %d:\n',r);
    
% Initialization Loop
for i=1:Pop_size
    
    if i > 1
        pop(i).Position=CreateRandomSolution(model);   %#ok
        zz = randi([0 1],1,model.n);
        tem1_pop = [pop(i).Position.x, pop(i).Position.y];
    else
        % Straight line from source to destination regardless of obstacles
        xx = linspace(model.xs, model.xt, model.n+2);
        yy = linspace(model.ys, model.yt, model.n+2);
        zz = randi([0 1],1,model.n);
        pop(i).Position.x = xx(2:end-1);     %#ok
        pop(i).Position.y = yy(2:end-1);     %#ok
        tem2_pop = [pop(i).Position.x, pop(i).Position.y];
    end
    
    
    % Evaluation
    try
        pos (i,:) = [pop(i).Position.x, pop(i).Position.y, zz,sum(zz)];    % Transformation
    catch
        return;
    end
    
    size_end=Num_waypoints*2;
    pos_x=pos(i,1:Num_waypoints);
    pos_y=pos(i,Num_waypoints+1:2*Num_waypoints);    
    
    pre_pos_x=zeros(1,pos(i,end));
    pre_pos_y=pre_pos_x;
    
    jj=1;
    for ii=size_end+1:D-1
        if (pos(i,ii)~=0)
            pre_pos_x(jj)=pos_x(1,ii-2*Num_waypoints);
            pre_pos_y(jj)=pos_y(1,ii-2*Num_waypoints);
            jj=jj+1;
        end
    end
    
    pre_pos=[pre_pos_x,pre_pos_y];
    temp=model.n;
    model.n=pos(i,end);
    
    [pop(i).Cost, pop(i).Sol]=MyCost(pre_pos,model);            %#ok
    fitness(i) = pop(i).Cost;                                   %#ok
    BestSol(i) = pop(i).Sol;                                    %#ok
    model.n=temp;

end

% Algorithms:

[GlobalBest_Cost_TLBO(r), fmins_TLBO(r,:), GlobalBest_param_TLBO(r), Flag_TLBO(r)] = TLBO_main_sim(Pop_size, Max_NFE, lb, ub, D , pos, fitness, BestSol, model,Num_waypoints*3);   %#ok

end

 
SD = abs (sqrt (S(1)*T(1) + S(2)*T(2)));  % Straight line between source and destination regardless of obstacles
SLR_TLBO = (min(GlobalBest_Cost_TLBO))/SD;
[z_TLBO, index_TLBO] = min(GlobalBest_Cost_TLBO);

% Print data:
fprintf('Environment Information:\nStart:[%d, %d]\nTarget:[%d, %d]\nN_Obs: %d\tNumber of waypoints:%d\n\n', S(1), S(2), T(1), T(2), N_Obs, Num_waypoints);
fprintf('-------------------------------------------------------------------------------------------------------------------------------------------\n');
fprintf('Algorithms:\t\tBest\t\t\t\tWorst\t\t\t\tMean\t\t\t\tS.D\t\t\t\tVoilation\t\t\tImproveRate\t\t\tSLR\n');
fprintf('-------------------------------------------------------------------------------------------------------------------------------------------\n');
fprintf('TLBO:\t\t%e\t\t%e\t\t%e\t\t%e\t\t%e\t\t%f\n', min(GlobalBest_Cost_TLBO), max(GlobalBest_Cost_TLBO), mean(GlobalBest_Cost_TLBO), std(GlobalBest_Cost_TLBO), Flag_TLBO(index_TLBO), SLR_TLBO);
 
% % Draw path:
figure(1)
title('TLBO')
PlotSolution(GlobalBest_param_TLBO(index_TLBO),model);
