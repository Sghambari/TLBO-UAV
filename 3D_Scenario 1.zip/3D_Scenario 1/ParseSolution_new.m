
function sol2=ParseSolution_new(sol1,model)
    vmax=500;
    vmin=1;
    x=sol1.x;
    y=sol1.y;
    
    xs=model.xs;
    ys=model.ys;
    xt=model.xt;
    yt=model.yt;
    xobs=model.xobs;
    yobs=model.yobs;
    
    % Using Cubic spline interpolation to smooth the path:
    XS=[xs x xt];
    YS=[ys y yt];
    k=numel(XS);
    TS=linspace(0,1,k);
    
    tt=linspace(0,1,1000);
    xx=spline(TS,XS,tt);
    yy=spline(TS,YS,tt);
    
    dx=diff(xx);
    dy=diff(yy);
    
    L=sum(sqrt(dx.^2+dy.^2));
    
    nobs = model.n_obs; % Number of Obstacles
    Violation = 0;
    
    for z = 1: size (xx, 2)
        %         d=sqrt((xx-xobs(k,:)).^2+(yy-yobs(k,:)).^2);
        %         v=max(1-d/robs(k),0);
        %         Violation=Violation+mean(v);

        for  kk=1:nobs
             obs_cor.x=xobs(kk,:)+4;
             obs_cor.y=yobs(kk,:)+4;
%             for j = 1: size (xobs(k,:), 2)
                if (xx(z)>=obs_cor.x(1)) && (xx(z)<=obs_cor.x(2)) && (yy(z)>=obs_cor.y(1)) && (yy(z)<=obs_cor.y(3))
%                     disp('A collision has been detected')
                    Violation=Violation+1000;
                end
%             end
        end
    end
   
    
    
    
    
%     k=1;
%     dsx=sqrt((XS(k)-XS(k+1)).^2);
%     dsy=sqrt((YS(k)-YS(k+1)).^2);
%     if dsx > vmax || dsx < vmin || dsy > vmax || dsy < vmin
%         Violation=Violation+dsx+dsy;
%     end    
%         
%     
%      for k=2:size(XS,2)-1
%          
%         dpx=sqrt((XS(k)-XS(k-1)).^2);
%         dsx=sqrt((XS(k)-XS(k+1)).^2);
% 
%         dpy=sqrt((YS(k)-YS(k-1)).^2);
%         dsy=sqrt((YS(k)-YS(k+1)).^2);
%         
%         if dpx > vmax || dpx < vmin || dsx > vmax || dsx < vmin || dpy > vmax || dpy < vmin || dsy > vmax || dsy < vmin
%             Violation=Violation+dpx+dsx+dpy+dsy;
%         end
%         
% %         if ds > vmax || ds < vmin
% %             Violation=Violation+ds;
% %         end        
%      end   
% 
%     k=size(XS,2);
%     dsx=sqrt((XS(k-1)-XS(k)).^2);
%     dsy=sqrt((YS(k-1)-YS(k)).^2);
%     if dsx > vmax || dsx < vmin || dsy > vmax || dsy < vmin
%         Violation=Violation+dsx+dsy;
%     end   
        
    
    sol2.TS=TS;
    sol2.XS=XS;
    sol2.YS=YS;
    sol2.tt=tt;
    sol2.xx=xx;
    sol2.yy=yy;
    sol2.dx=dx;
    sol2.dy=dy;
    sol2.L=L;
    sol2.Violation=Violation;
    sol2.IsFeasible=(Violation==1.0e-016);
    
    
end
