function [ch1, ch2] = Mutation_Opt(ch1, ch2)

        % Mutation Operator (Flip Bit):
        a = randi (size (ch1, 2) , [1, 2]);
        b = randi (size (ch1, 2) , [1, 2]);
        
        % Child 1:
        if ch1(a(1))==0
            ch1(a(1))=1;
        else 
            ch1(a(1))=0;
        end
        
        if ch1(a(2))==0
            ch1(a(2))=1;
        else
            ch1(a(2))=0;
        end
        
        % Child 2:
        if ch2(b(1))==0
            ch2(b(1))=1;
        else
            ch2(b(1))=0;
        end
        
        if ch2(b(2))==0
            ch2(b(2))=1;
        else
            ch2(b(2))=0;
        end
end