
function circles=getCentersWithoutOverlaps(nCircles, r)
circles = zeros(nCircles ,2);
a=0;
b=500;
for i=1:nCircles
    %Flag which holds true whenever a new circle was found
    newCircleFound = false;

    %loop iteration which runs until finding a circle which doesnt intersect with previous ones
    while ~newCircleFound
        x = a + rand(1).*b;
        y = a + rand(1).*b;

        %calculates distances from previous drawn circles
        prevCirclesY = circles(1:i-1,1);
        prevCirclesX = circles(1:i-1,2);
        distFromPrevCircles = ((prevCirclesX-x).^2+(prevCirclesY-y).^2).^0.5;

        %if the distance is not to small - adds the new circle to the list
        if i==1 || sum(distFromPrevCircles<=2*r(i))==0
            newCircleFound = true;
            circles(i,:) = [y x];
        end

    end
end