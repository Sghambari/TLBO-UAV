function  [ch1, ch2] = Crossovers_Opt(pop1, pop2,num_wp)

        p1 = pop1((num_wp/3)*2+1:end-1);
        p2 = pop2((num_wp/3)*2+1:end-1);
        
        
        %Onepoint Crossover:
        cs_point1 = randi (size (p1, 2));
        ch1 = [p1(1: cs_point1), p2(cs_point1+1:end)];
        ch2 = [p2(1: cs_point1), p1(cs_point1+1:end)];
% 
%         % Twopoint Crossover :
%         cs_point2_1 = randi (size (p1, 2));
%         cs_point2_2 = randi (size (p1, 2));
% 
%         while cs_point2_1 == cs_point2_2
%             cs_point2_2 = randi (size (p1, 2));
%         end
% 
%         if cs_point2_1 < cs_point2_2
%             cs_p_1 = cs_point2_1;
%             cs_p_2 = cs_point2_2;
%         else
%             cs_p_1 = cs_point2_2;
%             cs_p_2 = cs_point2_1;
%         end
%         
%         ch1 = [p1(1: cs_p_1), p2(cs_p_1+1:cs_p_2), p1(cs_p_2+1:end)];
%         ch2 = [p2(1: cs_p_1), p1(cs_p_1+1:cs_p_2), p2(cs_p_2+1:end)];

%         % Uniform Crossover:
%         Prob = 0.5;
%         for i = 1: size(p1, 2)
%             if rand < Prob
%                 ch1(i) = p1(i);
%                 ch2(i) = p2(i);
%             else 
%                 ch1(i) = p2(i);
%                 ch2(i) = p1(i);
%             end
%         end
        

%         % Random respectful CrossOver (RRC):
%         prob = 0.5;
%         for i = 1: size(p1, 2)
%             if p1(i) == p2(i)
%                 if p1(i) == 1 && p2(i)==1
%                     ch1(i) = p1(i);
%                     ch2(i) = p2(i);
%                 else
%                     if rand < prob
%                         ch1(i) = 1;
%                         ch2(i) = 1;
%                     else
%                         ch1(i) = 0;
%                         ch2(i) = 0;
%                     end
%                 end
%             else
%                 ch1(i) = 0;
%                 ch2(i) = 0;
%             end
%         end
        
        
            % Masked Crossover (MX):
            mask = randi([0 1],1,size (p1, 2));
            for i = 1: size(p1, 2)
                if mask (i) == 0
                    ch1 (i) = p1 (i);
                    ch2 (i) = p2 (i);
                else
                    ch1 (i) = p2(i);
                    ch2 (i) = p1 (i);
                end
            end
%         % Mutation Operator (Flip Bit):
%         a = randi (size (p1, 2) , [1, 2]);
%         b = randi (size (p1, 2) , [1, 2]);
%         
%         % Child 1:
%         if ch1(a(1))==0
%             ch1(a(1))=1;
%         else 
%             ch1(a(1))=0;
%         end
%         
%         if ch1(a(2))==0
%             ch1(a(2))=1;
%         else
%             ch1(a(2))=0;
%         end
%         
%         % Child 2:
%         if ch2(b(1))==0
%             ch2(b(1))=1;
%         else
%             ch2(b(1))=0;
%         end
%         
%         if ch2(b(2))==0
%             ch2(b(2))=1;
%         else
%             ch2(b(2))=0;
%         end
end