function [pre_pos, temp_wp] = ActiveInactive_Opt(pop, x, num_wp, D)
       
        pos_x1=pop(1:num_wp/3);
        pos_y1=pop((num_wp/3)+1:(num_wp/3)*2);

        pre_pos_x1=zeros(1,pop(end));
        pre_pos_y1=pre_pos_x1;

        jj=1;
        for ii=x+1:D-1
            if (pop(ii)~=0)
                pre_pos_x1(jj)=pos_x1(1,ii-(num_wp/3)*2);
                pre_pos_y1(jj)=pos_y1(1,ii-(num_wp/3)*2);
                jj=jj+1;
            end
        end

        pre_pos=[pre_pos_x1,pre_pos_y1];
%         temp1=model.n;
        temp_wp= sum (pop((num_wp/3)*2+1:end));
end