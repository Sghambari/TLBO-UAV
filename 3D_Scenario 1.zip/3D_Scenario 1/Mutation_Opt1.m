function [ch1] = Mutation_Opt1(ch1)

        
        % Mutation Operator (Flip Bit):
        a = randi (size (ch1, 2) , [1, 2]);
        
        % Child 1:
        if ch1(a(1))==0
            ch1(a(1))=1;
        else 
            ch1(a(1))=0;
        end
        
        if ch1(a(2))==0
            ch1(a(2))=1;
        else
            ch1(a(2))=0;
        end
        
        
        
end