
% Plot paths function:

function PlotSolution(sol,model)
%     close all;

    xs=model.xs;
    ys=model.ys;
    xt=model.xt;
    yt=model.yt;

    
    XS=sol.XS;
    YS=sol.YS;
    xx=sol.xx;
    yy=sol.yy;

%     % Obstacles information:
%     xobs = [620, 660, 660, 620];
%     yobs = [230, 230, 280, 280];
%     zobs = [0, 0, 0, 0];

    patch([620, 660, 660, 620], [230, 230, 280, 280], [0, 0, 0, 0], [0.8 0.8 0.8]);
    hold on;
    plot(xx,yy,'k','LineWidth',1.90);
    plot(XS,YS,'ro','MarkerSize',6,'MarkerFaceColor','r');
    plot(xs,ys,'bo','MarkerSize',8,'MarkerFaceColor','y');
    plot(xt,yt,'ko','MarkerSize',8,'MarkerFaceColor','g');
    hold off;
    grid on;
    axis equal;

end