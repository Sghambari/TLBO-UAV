
function [z, sol]=MyCost(pos,model)
    
    sol1.x = pos (1: model.n);
    sol1.y = pos (model.n+1:model.n*2);
    
    sol = ParseSolution_new(sol1,model);
    
    beta = 1000;
    z = sol.L+(1+beta*sol.Violation);

end