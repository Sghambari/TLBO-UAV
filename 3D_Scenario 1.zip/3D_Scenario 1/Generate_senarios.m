function model = Generate_senarios(S, T, n_obs, num_wp)

    

    
    % Generate random obstacles
%     rng(20);
    uav_ws =1;                  %UAV wing span
%     obs = rand(n_obs,2)*90+5;   %obstacle locations
%     xobs = (obs(:,1))';
%     yobs = (obs(:,2))';
    
%         rng(25);
%       rng(361);
%       s = rng
%     K = round(n_obs/4);
%     Z = round(n_obs/5)+6;
    obs_rad = (4-uav_ws) +  rand(n_obs,1)*65; %obstacle radius
    robs= (obs_rad)';
    
    centers=getCentersWithoutOverlaps(n_obs, robs);
    xobs = (centers(:,1))';
    yobs = (centers(:,2))';

     n=num_wp;                       %Number of waypoints

    
    model.xs=S(1);
    model.ys=S(2);
    model.xt=T(1);
    model.yt=T(2);
    model.xobs=xobs;
    model.yobs=yobs;
    model.robs=robs;
    model.n=n;
    model.xmin=S(1);
    model.xmax=T(1);
    model.ymin=S(2);
    model.ymax=T(2);

%     FileName=['Bench_',num2str(n_obs),'.txt'];
%     fileID = fopen(FileName,'w');
%     fprintf(fileID, 'Environment Information: \n');
%     fprintf(fileID, '---------------------------------------------------------\n');
%     fprintf(fileID, 'Start: [%d, %d]       Target: [%d, %d]      Num_Obs: %d \n', model.xs, model.ys, model.xt, model.yt, n_obs);
%     fprintf(fileID, '---------------------------------------------------------\n');    
%     fprintf(fileID, 'Obstacles positions and radiuses: \n');
%     fprintf(fileID, '\n');
%     fprintf(fileID, '%10.6f    %10.6f    %10.6f\n',model.xobs, model.yobs, model.robs);
    

end