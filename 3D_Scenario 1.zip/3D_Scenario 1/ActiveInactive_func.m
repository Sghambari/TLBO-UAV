function zz = ActiveInactive_func(sol, model)
xobs=model.xobs;
yobs=model.yobs;
robs=model.robs;
sol_x = sol (1: model.n);
sol_y = sol (model.n+1:model.n*2);
j = 1;
zz = true (1, model.n);
for i = 2: (size (sol_x, 2)-1)
    a = sol_x (i);
    b = sol_y (i);
    c = sol_x (i+1);
    d = sol_y (i+1);
    new_source = [a, b];
    new_destination = [c, d];
    x = [new_source(1), new_destination(1)];
    y = [new_source(2), new_destination(2)];
    k=numel(x );
    TS=linspace(0,1,k);
    
    tt=linspace(0,1,10);
    xx=spline(TS,x,tt);
    yy=spline(TS,y,tt);
    
    nobs = numel(xobs); % Number of Obstacles
    Violation = 0;
    for k=1:nobs
        d=sqrt((x-xobs(k)).^2+(y-yobs(k)).^2);
        v=max(1-d/robs(k),0);
        Violation=Violation+mean(v);
    end
%         if Violation == 0 && d >= robs/2
        if Violation == 0 
            zz (j) = false;
        end
        j = j+1;
end
end