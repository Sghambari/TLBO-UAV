
function model=CreateModel(start, target)

    % Source
    xs=start(1);
    ys=start(2);
    
    % Target (Destination)
    xt=target(1);
    yt=target(2);
    
    
    % Obstacles information:
    xobs = [620, 660, 660, 620];
    yobs = [230, 230, 280, 280];
    n_obs = size (xobs, 1);                %number of static obstacles

    n=50;                                  % number of way points
    
    xmin= start(1);
    xmax= target(1);
    
    ymin= start(2);
    ymax= target(2);
    
    model.xs=xs;
    model.ys=ys;
    model.xt=xt;
    model.yt=yt;
    model.n_obs=n_obs;
    model.xobs=xobs;
    model.yobs=yobs;
    model.n=n;
    model.xmin=xmin;
    model.xmax=xmax;
    model.ymin=ymin;
    model.ymax=ymax;
    
end