function zz = ActiveInactive_func_1(sol, model)
xobs=model.xobs;
yobs=model.yobs;
robs=model.robs;
sol_x = sol (1: model.n);
sol_y = sol (model.n+1:model.n*2);
Limit_points = 100;
Limit_obs = min(robs);
zz = true (1, model.n);
for i = 1: model.n-1   % For calculating distance between waypoints
       
    dis_pointTopoint  = sqrt ((sol_x(i) - sol_x(i+1))^2 + (sol_y(i) - sol_y(i+1))^2);    % Distance from point o point
    
    for j = 1: numel(model.robs)   % From each waypoint to all obstacles
        
        Violation = zeros (1, numel(model.robs));
        
        dis_obsTopoint(j) = sqrt ((sol_x(i+1) - xobs(j))^2 + (sol_y(i+1) - yobs(j))^2);
        
        if dis_obsTopoint(j) <= Limit_obs
           
            v=max(1-dis_obsTopoint(j)/robs(j),0);
            Violation(j)=Violation(j)+mean(v);
        
        end
        
    end
        Sum_Violation = sum (Violation);
        if Sum_Violation == 0
            if dis_pointTopoint <= Limit_points
                zz (i+1) = 0;
            else
                zz (i+1) = 1;
            end
        end
end
end




