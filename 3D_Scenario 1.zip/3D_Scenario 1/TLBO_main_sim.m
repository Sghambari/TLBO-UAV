% Standard Teaching learning based algorithm:

function [Best_Cost, BestCosts, GlobalSol, Flag] = TLBO_main_sim(nPop, MaxIt, VarMin, VarMax, nVar , pop, Cost, BestSol, model,nvw)


% Initialize Best Solution
Best_Cost = inf;

% Initialize Population Members
for i=1:nPop
    if Cost(i) < Best_Cost
        GlobalBestSol = pop(i,:); %#ok
        Best_Cost=Cost(i);
        GlobalSol=BestSol(i);
    end
end

% Initialize Best Cost Record
BestCosts = zeros(MaxIt,1);

% TLBO Main Loop
for it=1:MaxIt
    
    % Calculate Population Mean
    Mean = 0;
    for i=1:nPop
        Mean = Mean + pop(i,1:(nvw/3)*2);
    end
    Mean = Mean/nPop;
   
    [~,indx]=min(Cost);
    Teacher=pop(indx,:);
    
    % Teacher Phase
    for i=1:nPop
        % Teaching Factor
        TF = randi([1 2]);
        
        % Teaching (moving towards teacher)
        nnewsol = pop(i,1:(nvw/3)*2) ...
            + rand(1,(nvw/3)*2).*(Teacher(1:(nvw/3)*2) - TF*Mean);
        
        % Clipping
        nnewsol = max(nnewsol(1:(nvw/3)*2), VarMin);
        nnewsol = min(nnewsol(1:(nvw/3)*2), VarMax);
    
        % CrossOver operators to Optimize waypoints: 
        [ch1, ch2] = Crossovers_Opt1(pop(i, :), Teacher,nvw);
        new_sol1=[nnewsol, ch1];
        new_sol2=[nnewsol, ch2];
       
        % ActiveInactive operator to turn on or turn off genes in a chromosome:
        size_end=(nvw/3)*2;
        [pre_pos1, temp_wp1] = ActiveInactive_Opt(new_sol1, size_end, nvw, nVar);
        model.n = temp_wp1;
        [TTCost1, Sol1] = MyCost(pre_pos1,model);
        
        [pre_pos2, temp_wp2] = ActiveInactive_Opt(new_sol2, size_end, nvw, nVar);
        model.n = temp_wp2;
        [TTCost2, Sol2] = MyCost(pre_pos2,model);

        % Comparision between childs of CrossOver:       
        if TTCost1 < TTCost2
            TCost=TTCost1;
            Sol = Sol1;
            newsol = [new_sol1, sum(new_sol1((nvw/3)*2+1:end))];
        else
            TCost=TTCost2;
            Sol = Sol2;
            newsol = [new_sol2, sum(new_sol2((nvw/3)*2+1:end))];
        end
        
        
        % Comparision (General comparison):
        if TCost<Cost(i)
            pop(i,:) = newsol;
            Cost(i) = TCost;
            BestSol(i)=Sol;
            if Cost(i) < Best_Cost
                GlobalBestSol = pop(i,:); %#ok
                Best_Cost=TCost;
                GlobalSol=BestSol(i);
            end
        end
    end

    
    % Learner Phase
    for i=1:nPop
        
        A = 1:nPop;
        A(i)=[];
        j = A(randi(nPop-1));
        
        Step = pop(i,1:(nvw/3)*2) - pop(j,1:(nvw/3)*2);
        if Cost(j) < Cost(i)
            Step = -Step;
        end
        
        % Teaching (moving towards teacher)
        nnewsol = pop(i,1:(nvw/3)*2) + rand(1,(nvw/3)*2).*Step;
        
        % Clipping
        nnewsol = max(nnewsol(1:(nvw/3)*2), VarMin);
        nnewsol = min(nnewsol(1:(nvw/3)*2), VarMax);
        
        % CrossOver operators to Optimize waypoints: 
        [ch1, ch2] = Crossovers_Opt1(pop(i, :), Teacher,nvw);
        new_sol1=[nnewsol, ch1];
        new_sol2=[nnewsol, ch2];
        
        % ActiveInactive operator to turn on or turn off genes in a chromosome:
        size_end=(nvw/3)*2;
        [pre_pos1, temp_wp1] = ActiveInactive_Opt(new_sol1, size_end, nvw, nVar);
        model.n = temp_wp1;
        [TTCost1, Sol1] = MyCost(pre_pos1,model);

        [pre_pos2, temp_wp2] = ActiveInactive_Opt(new_sol2, size_end, nvw, nVar);
        model.n = temp_wp2;
        [TTCost2, Sol2] = MyCost(pre_pos2,model);
        
       % Comparision between childs of CrossOver:  
        if TTCost1 < TTCost2
            TCost=TTCost1;
            Sol = Sol1;
            newsol = [new_sol1, sum(new_sol1((nvw/3)*2+1:end))];
        else
            TCost=TTCost2;
            Sol = Sol2;
            newsol = [new_sol2, sum(new_sol2((nvw/3)*2+1:end))];
        end
        

        
        % Comparision (General comparison):
        if TCost<Cost(i)
            pop(i,:) = newsol;
            Cost(i)= TCost;
            BestSol(i)=Sol;
            if TCost < Best_Cost
                GlobalBestSol = pop(i,:);%#ok
                Best_Cost=TCost;
                GlobalSol=BestSol(i);
            end
        end
    end
    
    % Store Record for Current Iteration
    BestCosts(it) = Best_Cost;

    % Show feasible sol information
    if  GlobalSol.IsFeasible
        Flag = ' *';
    else
        Flag = GlobalSol.Violation;
    end
    
    % Show Iteration Information
    fprintf('it %d: Best Cost =%f, Violation =%8.16f \n',it, Best_Cost, Flag);
    
%     % Plot paths:
%     figure;
%     PlotSolution(GlobalSol,model);

    
end

% Results
% figure;
% %plot(BestCosts, 'LineWidth', 2);
% semilogy(BestCosts, 'LineWidth', 2);
% xlabel('Iteration');
% ylabel('Best Cost');
% grid on;
