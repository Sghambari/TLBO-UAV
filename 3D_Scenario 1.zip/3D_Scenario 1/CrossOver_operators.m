clc;
clear; 
close all;

% Onepoint CrossOver :
p1 = randi([0 1],1,10);
p2 = randi([0 1],1,10);
cs_point1 = randi (size (p1, 2));
ch1 = [p1(1: cs_point1), p2(cs_point1+1:end)];
ch2 = [p2(1: cs_point1), p1(cs_point1+1:end)];


clear;
% Twopoint Crossover :
p1 = randi([0 1],1,15);
p2 = randi([0 1],1,15);
cs_point2_1 = randi (size (p1, 2));
cs_point2_2 = randi (size (p1, 2));

while cs_point2_1 == cs_point2_2
    cs_point2_2 = randi (size (p1, 2));
end

if cs_point2_1 < cs_point2_2
    cs_p_1 = cs_point2_1;
    cs_p_2 = cs_point2_2;
else
    cs_p_1 = cs_point2_2;
    cs_p_2 = cs_point2_1;
end
ch1 = [p1(1: cs_p_1), p2(cs_p_1+1:cs_p_2), p1(cs_p_2+1:end)];
ch2 = [p2(1: cs_p_1), p1(cs_p_1+1:cs_p_2), p2(cs_p_2+1:end)];


clear;
% Uniform Crossover :
p1 = randi([0 1],1,10);
p2 = randi([0 1],1,10);

Prob = 0.5;
for i = 1: size(p1, 2)
    if rand < Prob
        ch1(i) = p1(i);
        ch2(i) = p2(i);
    else 
        ch1(i) = p2(i);
        ch2(i) = p1(i);
    end
end


clear;
% Average Crossover (AX):
p1 = randi([0 1],1,10);
p2 = randi([0 1],1,10);
ch =zeros (1, size(p1, 2));
for i = 1: size(p1, 2)
    v = [p1(i), p2(i)];
    x = mean (v);
    ch(i) = floor (x);
end

clear;
% Discrete Crossover (DC):
p1 = randi([0 1],1,10);
p2 = randi([0 1],1,10);
ch =zeros (1, size(p1, 2));
prob = 0.5;
for i = 1: size(p1, 2)
    if rand < prob
        ch(i) = p1(i);
    else
        ch(i) = p2(i);
    end
end


% *BINARY CROSSOVER* :

clear;
% Random respectful CrossOver (RRC):
p1 = randi([0 1],1,6);
p2 = randi([0 1],1,6);
prob = 0.5;
for i = 1: size(p1, 2)
    if p1(i) == p2(i)
        if p1(i) == 1 && p2(i)==1
            ch1(i) = p1(i);
            ch2(i) = p2(i);
        else
            if rand < prob
                ch1(i) = 1;
                ch2(i) = 1;
            else
                ch1(i) = 0;
                ch2(i) = 0;
            end
        end
    else
        ch1(i) = 0;
        ch2(i) = 0;
    end
end

clear;
% Masked Crossover (MX):
p1 = randi([0 1],1,10);
p2 = randi([0 1],1,10);
mask = randi([0 1],1,10);
for i = 1: size(p1, 2)
    if mask (i) == 0
        ch1 (i) = p1 (i);
        ch2 (i) = p2 (i);
    else
        ch1 (i) = p2(i);
        ch2 (i) = p1 (i);
    end
end


% Flat CrossOver (FC) :
% Heuristic/ Intermediate Crossover (HC/IC) :
% Static_based adaptive ono_uniform crossover (SANUX) :
% Shuffle CrossOver :
% Reduced Surogate Crossover :